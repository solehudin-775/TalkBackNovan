package com.novan.talkbacknovan;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.OneArgFunction;
import org.luaj.vm2.lib.VarArgFunction;

import java.util.Iterator;

/** Modul cjson dan json untuk Lua (encode dan decode) memakai org.json bawaan Android. */
final class LuaJson {
    private LuaJson() {}

    static void pasang(Globals g) {
        final LuaTable modul = new LuaTable();
        modul.set("encode", new OneArgFunction() {
            @Override
            public LuaValue call(LuaValue v) {
                try {
                    Object o = keJson(v);
                    if (o instanceof JSONObject || o instanceof JSONArray) return valueOf(o.toString());
                    if (o == JSONObject.NULL) return valueOf("null");
                    if (o instanceof String) return valueOf(JSONObject.quote((String) o));
                    return valueOf(String.valueOf(o));
                } catch (Exception e) {
                    throw new LuaError("cjson.encode: " + e.getMessage());
                }
            }
        });
        modul.set("decode", new OneArgFunction() {
            @Override
            public LuaValue call(LuaValue s) {
                try {
                    return dariJson(new JSONTokener(s.tojstring()).nextValue());
                } catch (Exception e) {
                    throw new LuaError("cjson.decode: " + e.getMessage());
                }
            }
        });
        LuaValue pemuat = new VarArgFunction() {
            @Override
            public Varargs invoke(Varargs args) {
                return modul;
            }
        };
        LuaValue preload = g.get("package").get("preload");
        preload.set("cjson", pemuat);
        preload.set("json", pemuat);
    }

    private static Object keJson(LuaValue v) throws Exception {
        switch (v.type()) {
            case LuaValue.TNIL:
                return JSONObject.NULL;
            case LuaValue.TBOOLEAN:
                return v.toboolean();
            case LuaValue.TNUMBER:
                if (v.isint()) return v.toint();
                double d = v.todouble();
                if (d == Math.rint(d) && Math.abs(d) < 9.0e15) return (long) d;
                return d;
            case LuaValue.TSTRING:
                return v.tojstring();
            case LuaValue.TTABLE: {
                LuaTable t = (LuaTable) v;
                int n = t.length();
                boolean larik = n > 0;
                int jumlah = 0;
                LuaValue k = LuaValue.NIL;
                while (true) {
                    Varargs nx = t.next(k);
                    k = nx.arg1();
                    if (k.isnil()) break;
                    jumlah++;
                    if (!k.isint() || k.toint() < 1 || k.toint() > n) larik = false;
                }
                if (larik && jumlah == n) {
                    JSONArray a = new JSONArray();
                    for (int i = 1; i <= n; i++) a.put(keJson(t.get(i)));
                    return a;
                }
                JSONObject o = new JSONObject();
                k = LuaValue.NIL;
                while (true) {
                    Varargs nx = t.next(k);
                    k = nx.arg1();
                    if (k.isnil()) break;
                    Object nilai = keJson(nx.arg(2));
                    o.put(k.tojstring(), nilai);
                }
                return o;
            }
            default:
                return JSONObject.NULL;
        }
    }

    private static LuaValue dariJson(Object o) throws Exception {
        if (o == null || o == JSONObject.NULL) return LuaValue.NIL;
        if (o instanceof Boolean) return LuaValue.valueOf(((Boolean) o).booleanValue());
        if (o instanceof Integer) return LuaValue.valueOf(((Integer) o).intValue());
        if (o instanceof Long) {
            long l = (Long) o;
            if (l >= Integer.MIN_VALUE && l <= Integer.MAX_VALUE) return LuaValue.valueOf((int) l);
            return LuaValue.valueOf((double) l);
        }
        if (o instanceof Number) return LuaValue.valueOf(((Number) o).doubleValue());
        if (o instanceof String) return LuaValue.valueOf((String) o);
        if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            LuaTable t = new LuaTable();
            for (int i = 0; i < a.length(); i++) t.set(i + 1, dariJson(a.get(i)));
            return t;
        }
        if (o instanceof JSONObject) {
            JSONObject j = (JSONObject) o;
            LuaTable t = new LuaTable();
            Iterator<String> it = j.keys();
            while (it.hasNext()) {
                String k = it.next();
                t.set(k, dariJson(j.get(k)));
            }
            return t;
        }
        return LuaValue.valueOf(String.valueOf(o));
    }
}
