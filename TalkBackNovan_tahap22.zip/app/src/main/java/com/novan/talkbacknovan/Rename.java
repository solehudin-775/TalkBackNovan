package com.novan.talkbacknovan;

import android.content.Context;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Aturan ganti nama elemen. Satu aturan per baris di pengaturan: "kunci=nama baru".
 * Kunci berupa id elemen ("id:com.contoh:id/tombol") atau teks asli elemen.
 */
final class Rename {
    private Rename() {}

    static String kunciUntuk(AccessibilityNodeInfo n, String label) {
        String id = n.getViewIdResourceName();
        if (id != null && !id.isEmpty()) return "id:" + id;
        return label == null ? "" : label.trim();
    }

    static String terapkan(Context c, AccessibilityNodeInfo n, String label) {
        String aturan = Prefs.get(c).getString(Prefs.K_NAMA, "");
        if (aturan.isEmpty()) return label;
        String id = n.getViewIdResourceName();
        String kunciId = id == null ? null : "id:" + id;
        String asli = label == null ? "" : label.trim();
        for (String baris : aturan.split("\n")) {
            int i = baris.indexOf('=');
            if (i <= 0) continue;
            String k = baris.substring(0, i).trim();
            String v = baris.substring(i + 1).trim();
            if (kunciId != null && k.equals(kunciId)) return v;
            if (!k.startsWith("id:") && !asli.isEmpty() && k.equalsIgnoreCase(asli)) return v;
        }
        return label;
    }

    static void simpan(Context c, String kunci, String nama) {
        String aturan = Prefs.get(c).getString(Prefs.K_NAMA, "");
        StringBuilder sb = new StringBuilder();
        for (String baris : aturan.split("\n")) {
            int i = baris.indexOf('=');
            if (i > 0 && baris.substring(0, i).trim().equals(kunci)) continue;
            if (!baris.trim().isEmpty()) sb.append(baris).append('\n');
        }
        if (nama != null && !nama.trim().isEmpty()) {
            sb.append(kunci.replace("\n", " ")).append('=').append(nama.trim().replace("\n", " ")).append('\n');
        }
        Prefs.get(c).edit().putString(Prefs.K_NAMA, sb.toString()).apply();
    }

    static String namaSaatIni(Context c, String kunci) {
        for (String baris : Prefs.get(c).getString(Prefs.K_NAMA, "").split("\n")) {
            int i = baris.indexOf('=');
            if (i > 0 && baris.substring(0, i).trim().equals(kunci)) return baris.substring(i + 1).trim();
        }
        return "";
    }
}
