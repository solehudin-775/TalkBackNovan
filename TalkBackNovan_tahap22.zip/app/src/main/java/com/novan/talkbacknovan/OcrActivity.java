package com.novan.talkbacknovan;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;

/** Menerima gambar yang dibagikan dari aplikasi lain lalu mengenali teksnya. */
public class OcrActivity extends Activity {
    private TextView hasil;
    private String teks = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("OCR");
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout k = new LinearLayout(this);
        k.setOrientation(LinearLayout.VERTICAL);
        k.setPadding(pad, pad, pad, pad);

        Button salin = new Button(this);
        salin.setText("Salin hasil");
        salin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = getSystemService(ClipboardManager.class);
                if (cm != null && !teks.isEmpty()) cm.setPrimaryClip(ClipData.newPlainText("OCR", teks));
            }
        });
        k.addView(salin);

        hasil = new TextView(this);
        hasil.setTextSize(18);
        hasil.setTextIsSelectable(true);
        hasil.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        hasil.setPadding(0, pad, 0, 0);
        ScrollView sv = new ScrollView(this);
        sv.addView(hasil);
        k.addView(sv);
        setContentView(k);

        Intent i = getIntent();
        Uri uri = Intent.ACTION_SEND.equals(i.getAction())
                ? (Uri) i.getParcelableExtra(Intent.EXTRA_STREAM) : i.getData();
        if (uri == null) {
            hasil.setText("Tidak ada gambar.");
            return;
        }
        if (!OcrKlien.adaKunci(this)) {
            hasil.setText("Kunci API Gemini atau Groq belum diisi. Isi di Pengaturan TalkBack Novan.");
            return;
        }
        Bitmap bmp = muat(uri);
        if (bmp == null) {
            hasil.setText("Gambar tidak bisa dibuka.");
            return;
        }
        hasil.setText("Mengenali teks...");
        OcrKlien.kenali(this, bmp, new OcrKlien.Hasil() {
            @Override
            public void selesai(String t, String galat) {
                if (isFinishing() || isDestroyed()) return;
                teks = t == null ? "" : t;
                hasil.setText(t != null ? t : galat);
            }
        });
    }

    private Bitmap muat(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream a = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(a, null, o);
            if (a != null) a.close();
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / s > 2400) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            InputStream c = getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(c, null, o);
            if (c != null) c.close();
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }
}
