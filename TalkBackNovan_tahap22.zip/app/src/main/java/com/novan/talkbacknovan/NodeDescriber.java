package com.novan.talkbacknovan;

import android.content.Context;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;

/** Menyusun kalimat ucapan dari sebuah elemen layar. */
final class NodeDescriber {
    private NodeDescriber() {}

    static String describe(Context ctx, AccessibilityNodeInfo n) {
        if (n == null) return "";
        boolean denganPeran = Prefs.get(ctx).getBoolean(Prefs.K_PERAN, true);
        ArrayList<String> bagian = new ArrayList<>();

        String label = label(n);
        if (TextUtils.isEmpty(label)) label = labelAnak(n, 0);
        label = Rename.terapkan(ctx, n, label);
        if (!TextUtils.isEmpty(label)) {
            bagian.add(label);
        } else if (n.isClickable()) {
            bagian.add("tanpa label");
        }

        if (denganPeran) {
            CharSequence rd = n.getExtras() == null ? null
                    : n.getExtras().getCharSequence("AccessibilityNodeInfo.roleDescription");
            String peran = !TextUtils.isEmpty(rd) ? rd.toString() : peranDari(n);
            if (!peran.isEmpty()) bagian.add(peran);
            if (n.isHeading()) bagian.add("judul");
        }

        if (n.isCheckable()) {
            bagian.add(teksStatus(n));
        } else {
            CharSequence sd = n.getStateDescription();
            if (!TextUtils.isEmpty(sd)) {
                bagian.add(sd.toString());
            } else {
                AccessibilityNodeInfo.RangeInfo ri = n.getRangeInfo();
                if (ri != null) {
                    String nilai = String.valueOf(Math.round(ri.getCurrent()));
                    if (ri.getType() == AccessibilityNodeInfo.RangeInfo.RANGE_TYPE_PERCENT) {
                        nilai += " persen";
                    }
                    bagian.add(nilai);
                }
            }
        }
        if (n.isSelected() && !n.isCheckable()) bagian.add("dipilih");
        if (!n.isEnabled()) bagian.add("nonaktif");

        return TextUtils.join(", ", bagian);
    }

    /** Seperti describe, ditambah petunjuk penggunaan bila diaktifkan (dipakai saat fokus pindah). */
    static String describeFokus(Context ctx, AccessibilityNodeInfo n) {
        String teks = describe(ctx, n);
        if (n == null || !Prefs.get(ctx).getBoolean(Prefs.K_PETUNJUK, true)) return teks;
        String petunjuk = null;
        if (n.isEditable()) petunjuk = "ketuk dua kali untuk mengetik";
        else if (n.isClickable()) petunjuk = "ketuk dua kali untuk membuka";
        if (n.isCheckable() && n.isClickable()) petunjuk = "ketuk dua kali untuk mengubah";
        return petunjuk == null ? teks : teks + ", " + petunjuk;
    }

    /** Teks inti elemen: deskripsi konten, atau teks, atau petunjuk untuk kolom isian. */
    static String label(AccessibilityNodeInfo n) {
        CharSequence cd = n.getContentDescription();
        CharSequence tx = n.getText();
        CharSequence petunjuk = n.getHintText();

        if (n.isPassword()) {
            if (!TextUtils.isEmpty(cd)) return cd.toString();
            if (!TextUtils.isEmpty(petunjuk)) return petunjuk.toString();
            return "";
        }
        if (n.isEditable()) {
            if (!TextUtils.isEmpty(tx)) return tx.toString();
            CharSequence dasar = !TextUtils.isEmpty(cd) ? cd : petunjuk;
            return TextUtils.isEmpty(dasar) ? "kosong" : dasar + ", kosong";
        }
        if (!TextUtils.isEmpty(cd)) return cd.toString();
        if (!TextUtils.isEmpty(tx)) return tx.toString();
        return "";
    }

    private static String labelAnak(AccessibilityNodeInfo n, int kedalaman) {
        if (kedalaman > 3) return "";
        ArrayList<String> hasil = new ArrayList<>();
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null || !c.isVisibleToUser()) continue;
            String l = label(c);
            if (TextUtils.isEmpty(l)) l = labelAnak(c, kedalaman + 1);
            if (!TextUtils.isEmpty(l)) hasil.add(l);
            if (c.isCheckable()) hasil.add(teksStatus(c));
        }
        return TextUtils.join(", ", hasil);
    }

    static String teksStatus(AccessibilityNodeInfo n) {
        if (!n.isCheckable()) return "";
        String k = kelas(n);
        boolean sakelar = k.contains("Switch") || k.contains("ToggleButton");
        boolean radio = k.contains("RadioButton");
        if (n.isChecked()) {
            return sakelar ? "hidup" : (radio ? "dipilih" : "dicentang");
        }
        return sakelar ? "mati" : (radio ? "tidak dipilih" : "tidak dicentang");
    }

    static String kelas(AccessibilityNodeInfo n) {
        CharSequence c = n.getClassName();
        return c == null ? "" : c.toString();
    }

    private static String peranDari(AccessibilityNodeInfo n) {
        if (n.isEditable()) return n.isPassword() ? "kolom kata sandi" : "kolom isian";
        String k = kelas(n);
        if (k.contains("Switch") || k.contains("ToggleButton")) return "sakelar";
        if (k.contains("CheckBox")) return "kotak centang";
        if (k.contains("RadioButton")) return "tombol radio";
        if (k.contains("ImageButton")) return "tombol gambar";
        if (k.contains("Button")) return "tombol";
        if (k.contains("EditText")) return "kolom isian";
        if (k.contains("SeekBar")) return "penggeser";
        if (k.contains("Spinner")) return "daftar pilihan";
        if (k.contains("ProgressBar")) return "indikator kemajuan";
        if (k.contains("ImageView")) return "gambar";
        return "";
    }
}
