package com.novan.talkbacknovan;

import android.app.Notification;
import android.content.pm.PackageManager;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

import java.util.Set;

/** Membacakan notifikasi baru: nama aplikasi, judul, dan isi. */
public class PendengarNotifikasi extends NotificationListenerService {
    static volatile boolean aktif;
    private String terakhir = "";
    private long waktuTerakhir;

    @Override
    public void onListenerConnected() {
        aktif = true;
    }

    @Override
    public void onListenerDisconnected() {
        aktif = false;
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        Notification n = sbn.getNotification();
        if (getPackageName().equals(sbn.getPackageName())) return;
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if (!Prefs.get(this).getBoolean(Prefs.K_NOTIF, true)) return;
        Set<String> hitam = Prefs.daftar(this, Prefs.K_HITAM_NOTIF);
        if (hitam.contains(sbn.getPackageName())) return;
        if (TalkBackNovanService.notifDiam(this, sbn.getPackageName())) return;

        CharSequence judul = n.extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence isi = n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (TextUtils.isEmpty(isi)) isi = n.extras.getCharSequence(Notification.EXTRA_TEXT);
        StringBuilder sb = new StringBuilder();
        if (Prefs.get(this).getBoolean(Prefs.K_NOTIF_APP, true)) {
            sb.append(labelAplikasi(sbn.getPackageName()));
        }
        if (!TextUtils.isEmpty(judul)) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(judul);
        }
        if (!TextUtils.isEmpty(isi) && !Prefs.get(this).getBoolean(Prefs.K_NOTIF_RINGKAS, false)) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(isi);
        }
        String teks = sb.toString().trim();
        if (teks.isEmpty()) return;
        long sekarang = SystemClock.uptimeMillis();
        if (teks.equals(terakhir) && sekarang - waktuTerakhir < 2000) return;
        terakhir = teks;
        waktuTerakhir = sekarang;
        TalkBackNovanService.ucapkanAntre(teks);
    }

    private String labelAplikasi(String paket) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(paket, 0)).toString();
        } catch (Exception e) {
            return paket;
        }
    }
}
