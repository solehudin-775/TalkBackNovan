package com.novan.talkbacknovan;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Mode baca: seluruh teks layar dalam satu halaman yang bisa dijelajahi per karakter, kata, atau paragraf. */
public class BacaActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Teks layar");
        final String teks = TalkBackNovanService.teksLayar == null ? "" : TalkBackNovanService.teksLayar;
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout k = new LinearLayout(this);
        k.setOrientation(LinearLayout.VERTICAL);
        k.setPadding(pad, pad, pad, pad);

        LinearLayout baris = new LinearLayout(this);
        baris.setOrientation(LinearLayout.HORIZONTAL);
        baris.addView(tombol("Salin semua", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager cm = getSystemService(ClipboardManager.class);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("teks layar", teks));
                Toast.makeText(BacaActivity.this, "Disalin", Toast.LENGTH_SHORT).show();
            }
        }));
        baris.addView(tombol("Bagikan", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, teks);
                startActivity(Intent.createChooser(i, "Bagikan teks"));
            }
        }));
        baris.addView(tombol("Tutup", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        }));
        k.addView(baris);

        TextView t = new TextView(this);
        t.setTextSize(18);
        t.setTextIsSelectable(true);
        t.setText(teks.isEmpty() ? "Tidak ada teks di layar." : teks);
        t.setPadding(0, pad, 0, 0);
        ScrollView sv = new ScrollView(this);
        sv.addView(t);
        k.addView(sv);
        setContentView(k);
    }

    private Button tombol(String teks, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(teks);
        b.setOnClickListener(l);
        return b;
    }
}
