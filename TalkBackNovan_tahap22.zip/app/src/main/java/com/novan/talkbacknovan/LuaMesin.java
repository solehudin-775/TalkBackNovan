package com.novan.talkbacknovan;

import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.ResourceFinder;
import org.luaj.vm2.lib.VarArgFunction;
import org.luaj.vm2.lib.jse.JsePlatform;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Satu plugin Lua yang sedang berjalan: punya lingkungan Lua sendiri dan catatan (log) sendiri. */
public final class LuaMesin {
    private static final int BATAS_LOG = 20000;

    /** Pembantu import bergaya AndroLua: import "android.widget.*" lalu pakai TextView langsung. */
    private static final String IMPORT_LUA =
            "local bindClass = luajava.bindClass\n"
            + "local loaded, pkgs, miss = luajava.loaded, {}, {}\n"
            + "local function coba(n) local ok, c = pcall(bindClass, n) if ok then return c end end\n"
            + "local G = _G\n"
            + "local mt = getmetatable(G) or {}\n"
            + "setmetatable(G, mt)\n"
            + "local lama = mt.__index\n"
            + "mt.__index = function(t, k)\n"
            + "  if type(k) == 'string' then\n"
            + "    local c = loaded[k]\n"
            + "    if c then return c end\n"
            + "    if not miss[k] then\n"
            + "      local nama = k:gsub('_', '$')\n"
            + "      for i = 1, #pkgs do\n"
            + "        c = coba(pkgs[i] .. nama)\n"
            + "        if c then loaded[k] = c return c end\n"
            + "      end\n"
            + "      miss[k] = true\n"
            + "    end\n"
            + "  end\n"
            + "  if type(lama) == 'function' then return lama(t, k) end\n"
            + "  if type(lama) == 'table' then return lama[k] end\n"
            + "end\n"
            + "function import(nama)\n"
            + "  if nama:sub(-2) == '.*' then pkgs[#pkgs + 1] = nama:sub(1, -2) miss = {} return end\n"
            + "  local c = coba((nama:gsub('_', '$')))\n"
            + "  if not c then error('kelas tidak ditemukan: ' .. nama, 2) end\n"
            + "  local pendek = nama:match('([^%.]+)$')\n"
            + "  loaded[pendek] = c\n"
            + "  G[pendek] = c\n"
            + "  return c\n"
            + "end\n"
            + "package.preload['import'] = function() return import end\n"
            + "Http = luajava.bindClass('com.androlua.Http')\n";

    private final String nama;
    private final File dir;
    private final Globals g;
    private final StringBuilder log = new StringBuilder();
    private boolean berjalan;
    private static final Handler UTAMA = new Handler(Looper.getMainLooper());

    LuaMesin(final TalkBackNovanService svc, String nama, final File dir) {
        this.nama = nama;
        this.dir = dir;
        g = JsePlatform.standardGlobals();
        g.finder = new ResourceFinder() {
            @Override
            public InputStream findResource(String nama) {
                try {
                    File f = new File(nama);
                    if (!f.isAbsolute()) f = new File(dir, nama);
                    return f.isFile() ? new FileInputStream(f) : null;
                } catch (Exception e) {
                    return null;
                }
            }
        };
        LuaJava.pasang(g);
        LuaJson.pasang(g);
        String d = dir.getAbsolutePath();
        g.get("package").set("path", LuaValue.valueOf(d + "/?.lua;" + d + "/?/init.lua;" + d + "/lua/?.lua"));
        LuaValue s = LuaJava.wrap(svc);
        g.set("service", s);
        g.set("this", s);
        g.set("print", new VarArgFunction() {
            @Override
            public Varargs invoke(Varargs a) {
                StringBuilder sb = new StringBuilder();
                for (int i = 1; i <= a.narg(); i++) {
                    if (i > 1) sb.append('\t');
                    sb.append(a.arg(i).tojstring());
                }
                final String teks = sb.toString();
                catat(teks);
                UTAMA.post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Toast.makeText(svc, teks, Toast.LENGTH_SHORT).show();
                        } catch (Exception ignored) {
                        }
                    }
                });
                return NONE;
            }
        });
        g.load(IMPORT_LUA, "import").call();
    }

    String nama() {
        return nama;
    }

    boolean berjalan() {
        return berjalan;
    }

    synchronized void catat(String teks) {
        log.append(teks).append('\n');
        if (log.length() > BATAS_LOG) log.delete(0, log.length() - BATAS_LOG / 2);
    }

    synchronized String catatan() {
        return log.toString();
    }

    /** Jalankan main.lua; mengembalikan pesan galat, atau null bila berhasil. */
    String mulai() {
        try {
            File main = new File(dir, "main.lua");
            byte[] b = new byte[(int) main.length()];
            try (FileInputStream in = new FileInputStream(main)) {
                int n = 0;
                while (n < b.length) {
                    int r = in.read(b, n, b.length - n);
                    if (r < 0) break;
                    n += r;
                }
            }
            String src = new String(b, StandardCharsets.UTF_8);
            if (src.startsWith("\uFEFF")) src = src.substring(1);
            g.load(src, "main.lua").call();
            berjalan = true;
            panggil("onCreate");
            return null;
        } catch (Throwable t) {
            String m = pesan(t);
            catat("GALAT: " + m);
            return m;
        }
    }

    void berhenti() {
        if (berjalan) panggil("onDestroy");
        berjalan = false;
    }

    private static String pesan(Throwable t) {
        String m = t.getMessage();
        return m == null ? t.toString() : m;
    }

    /** Panggil fungsi global Lua bila ada; galat dicatat, tidak dilempar. */
    Varargs panggil(String fungsi, LuaValue... arg) {
        LuaValue f;
        try {
            f = g.rawget(fungsi);
        } catch (Throwable t) {
            return LuaValue.NONE;
        }
        if (!f.isfunction()) return LuaValue.NONE;
        try {
            return f.invoke(LuaValue.varargsOf(arg));
        } catch (Throwable t) {
            catat("GALAT di " + fungsi + ": " + pesan(t));
            return LuaValue.NONE;
        }
    }

    boolean punya(String fungsi) {
        try {
            return g.rawget(fungsi).isfunction();
        } catch (Throwable t) {
            return false;
        }
    }
}
