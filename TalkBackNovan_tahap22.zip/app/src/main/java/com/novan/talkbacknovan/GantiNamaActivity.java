package com.novan.talkbacknovan;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Dialog kecil untuk mengganti nama elemen yang sedang difokuskan. */
public class GantiNamaActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Ganti nama elemen");
        final String kunci = getIntent().getStringExtra("kunci");
        String label = getIntent().getStringExtra("label");
        if (kunci == null || kunci.isEmpty()) {
            finish();
            return;
        }
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout k = new LinearLayout(this);
        k.setOrientation(LinearLayout.VERTICAL);
        k.setPadding(pad, pad, pad, pad);

        TextView t = new TextView(this);
        t.setText("Elemen: " + (label == null || label.isEmpty() ? kunci : label));
        k.addView(t);

        final EditText e = new EditText(this);
        e.setHint("Nama baru");
        e.setContentDescription("Nama baru");
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setText(Rename.namaSaatIni(this, kunci));
        k.addView(e);

        Button simpan = new Button(this);
        simpan.setText("Simpan");
        simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Rename.simpan(GantiNamaActivity.this, kunci, e.getText().toString());
                finish();
            }
        });
        k.addView(simpan);

        Button hapus = new Button(this);
        hapus.setText("Hapus nama baru");
        hapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Rename.simpan(GantiNamaActivity.this, kunci, "");
                finish();
            }
        });
        k.addView(hapus);

        Button batal = new Button(this);
        batal.setText("Batal");
        batal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        k.addView(batal);
        setContentView(k);
    }
}
