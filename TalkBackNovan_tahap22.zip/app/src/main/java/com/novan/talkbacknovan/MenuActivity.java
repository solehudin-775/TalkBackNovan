package com.novan.talkbacknovan;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Menu konteks untuk elemen yang sedang difokuskan, dan Menu utama (judul, daftar, dan tombol
 * AKSI, BATAL, LEBIH seperti di JieShuo).
 */
public class MenuActivity extends Activity {
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTheme(android.R.style.Theme_DeviceDefault_Dialog);
        final boolean utama = TalkBackNovanService.menuUtamaAktif;
        TalkBackNovanService.menuUtamaAktif = false;
        setTitle(TalkBackNovanService.judulMenu);
        final java.util.List<String> item = TalkBackNovanService.daftarMenu;
        if (item == null || item.isEmpty()) {
            finish();
            return;
        }
        float d = getResources().getDisplayMetrics().density;
        LinearLayout akar = new LinearLayout(this);
        akar.setOrientation(LinearLayout.VERTICAL);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>(item));
        ListView lv = new ListView(this);
        lv.setAdapter(adapter);
        int tinggi = (int) (getResources().getDisplayMetrics().heightPixels * 0.6f);
        akar.addView(lv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, tinggi));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                if (TalkBackNovanService.bukaSubmenu(pos)) {
                    segarkan();
                    return;
                }
                TalkBackNovanService.pilihMenu(pos);
                finish();
            }
        });

        if (utama) {
            LinearLayout baris = new LinearLayout(this);
            baris.setOrientation(LinearLayout.HORIZONTAL);
            baris.setPadding((int) (8 * d), 0, (int) (8 * d), (int) (4 * d));
            baris.addView(tombol("AKSI", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                    TalkBackNovanService.menuAksi();
                }
            }));
            View pengisi = new View(this);
            baris.addView(pengisi, new LinearLayout.LayoutParams(0, 1, 1f));
            baris.addView(tombol("BATAL", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            }));
            baris.addView(tombol("LEBIH", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TalkBackNovanService.menuLebih();
                    segarkan();
                }
            }));
            akar.addView(baris);
        }
        setContentView(akar);
    }

    private Button tombol(String teks, View.OnClickListener l) {
        Button t = new Button(this, null, android.R.attr.borderlessButtonStyle);
        t.setText(teks);
        t.setOnClickListener(l);
        return t;
    }

    private void segarkan() {
        adapter.clear();
        adapter.addAll(TalkBackNovanService.daftarMenu);
        adapter.notifyDataSetChanged();
        setTitle(TalkBackNovanService.judulMenu);
    }
}
