package com.novan.talkbacknovan;

import android.graphics.Canvas;
import android.graphics.Color;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

/**
 * Wallpaper hidup polos hitam. Seperti "Wallpaper Jieshuo": memasang aplikasi sebagai wallpaper
 * membuat proses lebih stabil di latar belakang pada ponsel yang suka mematikan layanan saat layar mati.
 * Hitam juga hemat baterai di layar OLED.
 */
public class NovanWallpaper extends WallpaperService {
    @Override
    public Engine onCreateEngine() {
        return new MesinHitam();
    }

    private final class MesinHitam extends Engine {
        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            gambar(holder);
        }

        @Override
        public void onSurfaceRedrawNeeded(SurfaceHolder holder) {
            super.onSurfaceRedrawNeeded(holder);
            gambar(holder);
        }

        private void gambar(SurfaceHolder holder) {
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) c.drawColor(Color.BLACK);
            } catch (Exception ignore) {
            } finally {
                if (c != null) {
                    try {
                        holder.unlockCanvasAndPost(c);
                    } catch (Exception ignore) {
                    }
                }
            }
        }
    }
}
