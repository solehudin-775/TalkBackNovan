package com.novan.talkbacknovan;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Set;

/**
 * Jam bicara dan timer hitung mundur (Pengaturan Jam dan Timer ala JieShuo).
 * Punya mesin TTS sendiri supaya pengaturannya terpisah dari ucapan pembaca layar.
 * Hidup selama layanan aksesibilitas berjalan; dipakai dari {@link TalkBackNovanService}.
 */
public final class JamTimer {
    static final String AKSI_JAM = "com.novan.talkbacknovan.JAM_BICARA";
    static final String AKSI_TIMER = "com.novan.talkbacknovan.TIMER_SELESAI";

    private static JamTimer instansi;

    /** Objek yang sedang hidup, atau null bila layanan belum aktif. */
    public static JamTimer ada() {
        return instansi;
    }

    private final Context ctx;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AlarmManager alarm;
    private BroadcastReceiver penerima;

    private TextToSpeech tts;
    private boolean ttsSiap;
    private String mesinAktif = "";
    private String tertunda;

    private boolean timerJalan;
    private boolean timerJeda;
    private long timerAkhir;      // elapsedRealtime saat timer selesai
    private long timerSisaJeda;   // milidetik tersisa saat dijeda
    private long timerTotal;
    private String timerNama = "";
    private long detikTerakhir = -1;

    public JamTimer(Context c) {
        ctx = c.getApplicationContext();
        alarm = ctx.getSystemService(AlarmManager.class);
    }

    public void mulai() {
        instansi = this;
        penerima = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                if (i == null || i.getAction() == null) return;
                if (AKSI_JAM.equals(i.getAction())) bacaJam();
                else if (AKSI_TIMER.equals(i.getAction())) cekTimer();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(AKSI_JAM);
        f.addAction(AKSI_TIMER);
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(penerima, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            ctx.registerReceiver(penerima, f);
        }
        jadwalkanJam();
    }

    public void tutup() {
        batalkanJam();
        batalkanAlarmTimer();
        handler.removeCallbacksAndMessages(null);
        if (penerima != null) {
            try {
                ctx.unregisterReceiver(penerima);
            } catch (Exception ignore) {
            }
            penerima = null;
        }
        timerJalan = false;
        tutupTts();
        if (instansi == this) instansi = null;
    }

    /** Dipanggil saat pengaturan berubah. */
    public void perbarui() {
        jadwalkanJam();
        String mesin = Prefs.get(ctx).getString(Prefs.K_TIMER_MESIN, "");
        if (tts != null && !mesin.equals(mesinAktif)) tutupTts();
    }

    // ------------------------------------------------------------------ jam bicara

    private PendingIntent maksudSiaran(int kode, String aksi) {
        Intent i = new Intent(aksi).setPackage(ctx.getPackageName());
        return PendingIntent.getBroadcast(ctx, kode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void batalkanJam() {
        if (alarm != null) alarm.cancel(maksudSiaran(1, AKSI_JAM));
    }

    /** Pasang alarm berikutnya pada kelipatan interval menit (mis. 15: 14.00, 14.15, 14.30). */
    private void jadwalkanJam() {
        batalkanJam();
        SharedPreferences sp = Prefs.get(ctx);
        if (alarm == null || !sp.getBoolean(Prefs.K_ALARM, false)) return;
        int iv = Math.max(1, sp.getInt(Prefs.K_ALARM_INTERVAL, 15));
        Calendar c = Calendar.getInstance();
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        int menitHari = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        int berikut = (menitHari / iv + 1) * iv;
        c.add(Calendar.MINUTE, berikut - menitHari);
        try {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), maksudSiaran(1, AKSI_JAM));
        } catch (Exception ignore) {
        }
    }

    private void bacaJam() {
        SharedPreferences sp = Prefs.get(ctx);
        if (sp.getBoolean(Prefs.K_ALARM, false)) {
            Set<String> jam = Prefs.daftar(ctx, Prefs.K_ALARM_JAM);
            Calendar c = Calendar.getInstance();
            if (jam.isEmpty() || jam.contains(String.valueOf(c.get(Calendar.HOUR_OF_DAY)))) {
                ucap("Pukul " + new SimpleDateFormat("HH.mm", Locale.getDefault()).format(c.getTime()));
            }
        }
        jadwalkanJam();
    }

    // ------------------------------------------------------------------ timer hitung mundur

    private boolean ucapAktif() {
        return Prefs.get(ctx).getBoolean(Prefs.K_TIMER_UCAP, true);
    }

    private void pasangAlarmTimer(long akhirElapsed) {
        if (alarm == null) return;
        try {
            alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, akhirElapsed, maksudSiaran(2, AKSI_TIMER));
        } catch (Exception ignore) {
        }
    }

    private void batalkanAlarmTimer() {
        if (alarm != null) alarm.cancel(maksudSiaran(2, AKSI_TIMER));
    }

    public void mulaiTimer(long milidetik, String nama) {
        if (milidetik <= 0) return;
        handler.removeCallbacks(denyut);
        timerTotal = milidetik;
        timerNama = nama == null ? "" : nama;
        timerAkhir = SystemClock.elapsedRealtime() + milidetik;
        timerJalan = true;
        timerJeda = false;
        detikTerakhir = -1;
        pasangAlarmTimer(timerAkhir);
        if (ucapAktif()) ucap("Timer dimulai, " + durasi(milidetik));
        handler.postDelayed(denyut, 500);
    }

    public void hentikanTimer() {
        if (!timerJalan) return;
        timerJalan = false;
        timerJeda = false;
        handler.removeCallbacks(denyut);
        batalkanAlarmTimer();
        if (ucapAktif()) ucap("Timer dihentikan");
    }

    /** Jeda bila sedang berjalan, lanjutkan bila sedang dijeda. */
    public void jedaLanjut() {
        if (!timerJalan) return;
        if (!timerJeda) {
            timerSisaJeda = Math.max(0, timerAkhir - SystemClock.elapsedRealtime());
            timerJeda = true;
            handler.removeCallbacks(denyut);
            batalkanAlarmTimer();
            if (ucapAktif()) ucap("Timer dijeda, sisa " + durasi(timerSisaJeda));
        } else {
            timerAkhir = SystemClock.elapsedRealtime() + timerSisaJeda;
            timerJeda = false;
            pasangAlarmTimer(timerAkhir);
            if (ucapAktif()) ucap("Timer dilanjutkan");
            handler.postDelayed(denyut, 500);
        }
    }

    public boolean timerBerjalan() {
        return timerJalan;
    }

    public boolean timerDijeda() {
        return timerJalan && timerJeda;
    }

    public String status() {
        if (!timerJalan) return "Tidak ada timer yang berjalan.";
        long sisa = timerJeda ? timerSisaJeda : Math.max(0, timerAkhir - SystemClock.elapsedRealtime());
        String nama = timerNama.isEmpty() ? "" : " (" + timerNama + ")";
        return (timerJeda ? "Timer dijeda" : "Timer berjalan") + nama + ", sisa " + durasi(sisa) + ".";
    }

    private void cekTimer() {
        if (timerJalan && !timerJeda && timerAkhir - SystemClock.elapsedRealtime() <= 1000) selesaiTimer();
    }

    private final Runnable denyut = new Runnable() {
        @Override
        public void run() {
            if (!timerJalan || timerJeda) return;
            long sisa = timerAkhir - SystemClock.elapsedRealtime();
            if (sisa <= 0) {
                selesaiTimer();
                return;
            }
            long detik = (sisa + 999) / 1000;
            long selang = Prefs.get(ctx).getInt(Prefs.K_TIMER_INTERVAL, 10) * 60L;
            if (selang > 0 && detik % selang == 0 && detik != detikTerakhir && detik != (timerTotal + 999) / 1000) {
                detikTerakhir = detik;
                if (ucapAktif()) ucap("Sisa " + durasi(sisa));
            }
            handler.postDelayed(this, 500);
        }
    };

    private void selesaiTimer() {
        timerJalan = false;
        timerJeda = false;
        handler.removeCallbacks(denyut);
        batalkanAlarmTimer();
        SharedPreferences sp = Prefs.get(ctx);
        if (sp.getBoolean(Prefs.K_TIMER_GETAR, true)) getar();
        if (sp.getBoolean(Prefs.K_TIMER_SUARA, true)) bunyi();
        if (ucapAktif()) ucap("Timer selesai" + (timerNama.isEmpty() ? "" : ", " + timerNama));
    }

    private void getar() {
        try {
            Vibrator v = ctx.getSystemService(Vibrator.class);
            if (v != null && v.hasVibrator()) {
                v.vibrate(VibrationEffect.createWaveform(new long[]{0, 400, 200, 400, 200, 400}, -1));
            }
        } catch (Exception ignore) {
        }
    }

    private void bunyi() {
        try {
            final ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_ALARM, 80);
            for (int i = 0; i < 3; i++) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 250);
                        } catch (Exception ignore) {
                        }
                    }
                }, i * 500L);
            }
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    tg.release();
                }
            }, 2500);
        } catch (RuntimeException ignore) {
        }
    }

    /** "1 jam 5 menit 10 detik"; bagian nol dilewati. */
    static String durasi(long milidetik) {
        long total = Math.max(0, (milidetik + 999) / 1000);
        long jam = total / 3600;
        long menit = (total % 3600) / 60;
        long detik = total % 60;
        StringBuilder sb = new StringBuilder();
        if (jam > 0) sb.append(jam).append(" jam ");
        if (menit > 0) sb.append(menit).append(" menit ");
        if (detik > 0 || sb.length() == 0) sb.append(detik).append(" detik ");
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------ TTS khusus jam dan timer

    /** Ucapkan lewat mesin TTS jam dan timer (pengaturannya terpisah dari pembaca layar). */
    public void ucap(final String teks) {
        String mesin = Prefs.get(ctx).getString(Prefs.K_TIMER_MESIN, "");
        if (tts != null && !mesin.equals(mesinAktif)) tutupTts();
        if (tts == null) {
            tertunda = teks;
            ttsSiap = false;
            mesinAktif = mesin;
            TextToSpeech.OnInitListener l = new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (tts == null) return;
                    if (status != TextToSpeech.SUCCESS) {
                        tutupTts();
                        return;
                    }
                    ttsSiap = true;
                    try {
                        tts.setLanguage(new Locale("id", "ID"));
                    } catch (Exception ignore) {
                    }
                    if (tertunda != null) {
                        String t = tertunda;
                        tertunda = null;
                        bicara(t);
                    }
                }
            };
            tts = mesin.isEmpty() ? new TextToSpeech(ctx, l) : new TextToSpeech(ctx, l, mesin);
        } else if (!ttsSiap) {
            tertunda = teks;
        } else {
            bicara(teks);
        }
    }

    private void bicara(String teks) {
        SharedPreferences sp = Prefs.get(ctx);
        try {
            tts.setSpeechRate(sp.getInt(Prefs.K_TIMER_LAJU, 100) / 100f);
            tts.setPitch(sp.getInt(Prefs.K_TIMER_NADA, 100) / 100f);
            int saluran = sp.getInt(Prefs.K_TIMER_SALURAN, 0);
            int usage = saluran == 1 ? AudioAttributes.USAGE_ALARM
                    : saluran == 2 ? AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY
                    : AudioAttributes.USAGE_MEDIA;
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            Bundle b = new Bundle();
            b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, sp.getInt(Prefs.K_TIMER_VOLUME, 100) / 100f);
            tts.speak(teks, TextToSpeech.QUEUE_ADD, b, "jamtimer" + System.nanoTime());
        } catch (Exception ignore) {
        }
    }

    private void tutupTts() {
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignore) {
            }
            tts = null;
        }
        ttsSiap = false;
        tertunda = null;
    }
}
