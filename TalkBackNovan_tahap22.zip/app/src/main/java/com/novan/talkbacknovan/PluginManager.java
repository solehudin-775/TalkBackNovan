package com.novan.talkbacknovan;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Pengelola ekstensi (plugin Lua). Tiap plugin adalah folder berisi main.lua di
 * Android/data/com.novan.talkbacknovan/files/plugin/NAMA/.
 */
public final class PluginManager {
    private PluginManager() {}

    public static final String K_OTOMATIS = "plugin_otomatis"; // himpunan nama plugin yang jalan otomatis

    private static final Map<String, LuaMesin> JALAN = new LinkedHashMap<>();
    private static final StringBuilder UMUM = new StringBuilder();
    private static boolean dalamUcap;

    public static synchronized void catatUmum(String pesan) {
        UMUM.append(pesan).append('\n');
        if (UMUM.length() > 10000) UMUM.delete(0, UMUM.length() - 5000);
    }

    public static synchronized String catatanUmum() {
        return UMUM.toString();
    }

    public static File folder(Context c) {
        File dasar = c.getExternalFilesDir(null);
        if (dasar == null) dasar = c.getFilesDir();
        File f = new File(dasar, "plugin");
        if (!f.exists()) f.mkdirs();
        return f;
    }

    public static List<String> daftar(Context c) {
        List<String> hasil = new ArrayList<>();
        File[] anak = folder(c).listFiles();
        if (anak == null) return hasil;
        Arrays.sort(anak);
        for (File f : anak) {
            if (f.isDirectory() && new File(f, "main.lua").isFile()) hasil.add(f.getName());
        }
        return hasil;
    }

    public static synchronized boolean berjalan(String nama) {
        LuaMesin m = JALAN.get(nama);
        return m != null && m.berjalan();
    }

    public static synchronized String catatan(String nama) {
        LuaMesin m = JALAN.get(nama);
        return m == null ? "" : m.catatan();
    }

    public static boolean otomatis(Context c, String nama) {
        return Prefs.daftar(c, K_OTOMATIS).contains(nama);
    }

    public static void aturOtomatis(Context c, String nama, boolean hidup) {
        java.util.Set<String> s = Prefs.daftar(c, K_OTOMATIS);
        if (hidup) s.add(nama);
        else s.remove(nama);
        Prefs.get(c).edit().putStringSet(K_OTOMATIS, s).apply();
    }

    /** Jalankan plugin; mengembalikan pesan galat atau null bila berhasil. */
    public static String mulai(Context c, String nama) {
        TalkBackNovanService svc = TalkBackNovanService.instance;
        if (svc == null) return "Layanan aksesibilitas belum aktif. Aktifkan TalkBack Novan dulu.";
        File dir = new File(folder(c), nama);
        if (!new File(dir, "main.lua").isFile()) return "main.lua tidak ditemukan.";
        henti(nama);
        LuaMesin m;
        try {
            m = new LuaMesin(svc, nama, dir);
        } catch (Throwable t) {
            return "Mesin Lua gagal dibuat: " + t;
        }
        synchronized (PluginManager.class) {
            JALAN.put(nama, m);
        }
        String galat = m.mulai();
        if (galat != null) {
            // Catatan tetap tersimpan di JALAN agar galatnya bisa dibaca; plugin dianggap berhenti.
            return galat;
        }
        return null;
    }

    public static synchronized void henti(String nama) {
        LuaMesin m = JALAN.get(nama);
        if (m != null) {
            m.berhenti();
            JALAN.remove(nama);
        }
    }

    public static synchronized void hentiSemua() {
        for (LuaMesin m : new ArrayList<>(JALAN.values())) m.berhenti();
        JALAN.clear();
    }

    public static void mulaiOtomatis(Context c) {
        for (String nama : daftar(c)) {
            if (otomatis(c, nama) && !berjalan(nama)) mulai(c, nama);
        }
    }

    public static String hapus(Context c, String nama) {
        henti(nama);
        aturOtomatis(c, nama, false);
        hapusRekursif(new File(folder(c), nama));
        return "Plugin " + nama + " dihapus.";
    }

    private static void hapusRekursif(File f) {
        File[] anak = f.listFiles();
        if (anak != null) for (File a : anak) hapusRekursif(a);
        f.delete();
    }

    public static String baca(Context c, String nama) {
        File f = new File(new File(folder(c), nama), "main.lua");
        try (InputStream in = new java.io.FileInputStream(f)) {
            return new String(baca(in), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    /** Simpan kode sebagai main.lua pada plugin NAMA (membuat plugin baru bila belum ada). */
    public static String simpan(Context c, String nama, String kode) {
        String bersih = namaAman(nama);
        if (bersih.isEmpty()) return "Nama plugin tidak valid.";
        File dir = new File(folder(c), bersih);
        dir.mkdirs();
        try (FileOutputStream out = new FileOutputStream(new File(dir, "main.lua"))) {
            out.write(kode.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return "Gagal menyimpan: " + e.getMessage();
        }
        return "Plugin " + bersih + " disimpan.";
    }

    static String namaAman(String s) {
        if (s == null) return "";
        String r = s.trim().replaceAll("[^\\p{L}\\p{N} ._-]", "_");
        while (r.startsWith(".")) r = r.substring(1);
        return r.length() > 60 ? r.substring(0, 60) : r;
    }

    private static byte[] baca(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    /** Pasang plugin dari berkas .lua (jadi main.lua) atau .zip (folder plugin). */
    public static String pasang(Context c, Uri uri) {
        String nama = "plugin";
        try (Cursor cur = c.getContentResolver().query(uri, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) nama = cur.getString(i);
            }
        } catch (Exception ignored) {
        }
        boolean zip = nama.toLowerCase().endsWith(".zip");
        String dasar = namaAman(nama.replaceAll("(?i)\\.(zip|lua)$", ""));
        if (dasar.isEmpty()) dasar = "plugin";
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) return "Berkas tidak bisa dibuka.";
            byte[] isi = baca(in);
            if (!zip) {
                return simpan(c, dasar, new String(isi, StandardCharsets.UTF_8));
            }
            return pasangZip(c, dasar, isi);
        } catch (Exception e) {
            return "Gagal memasang: " + e.getMessage();
        }
    }

    private static String pasangZip(Context c, String dasar, byte[] isi) throws Exception {
        // Bila semua isi berada dalam satu folder teratas, folder itu diratakan.
        String awalan = null;
        boolean satuFolder = true;
        try (ZipInputStream z = new ZipInputStream(new java.io.ByteArrayInputStream(isi))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String n = e.getName();
                int p = n.indexOf('/');
                String atas = p < 0 ? "" : n.substring(0, p + 1);
                if (atas.isEmpty()) {
                    if (!e.isDirectory()) satuFolder = false;
                } else if (awalan == null) {
                    awalan = atas;
                } else if (!awalan.equals(atas)) {
                    satuFolder = false;
                }
            }
        }
        String buang = satuFolder && awalan != null ? awalan : "";
        File dir = new File(folder(c), dasar);
        hapusRekursif(dir);
        dir.mkdirs();
        String dasarKanonik = dir.getCanonicalPath() + File.separator;
        boolean adaMain = false;
        try (ZipInputStream z = new ZipInputStream(new java.io.ByteArrayInputStream(isi))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String n = e.getName();
                if (!buang.isEmpty()) {
                    if (!n.startsWith(buang)) continue;
                    n = n.substring(buang.length());
                }
                if (n.isEmpty()) continue;
                File tujuan = new File(dir, n);
                if (!tujuan.getCanonicalPath().startsWith(dasarKanonik)) continue; // cegah zip-slip
                if (e.isDirectory()) {
                    tujuan.mkdirs();
                    continue;
                }
                tujuan.getParentFile().mkdirs();
                try (FileOutputStream out = new FileOutputStream(tujuan)) {
                    byte[] buf = new byte[8192];
                    int r;
                    while ((r = z.read(buf)) > 0) out.write(buf, 0, r);
                }
                if (n.equals("main.lua")) adaMain = true;
            }
        }
        if (!adaMain) {
            hapusRekursif(dir);
            return "Zip tidak berisi main.lua.";
        }
        return "Plugin " + dasar + " dipasang.";
    }

    // ------------------------------------------------------------------ pengait peristiwa

    private static synchronized List<LuaMesin> salinan() {
        return JALAN.isEmpty() ? null : new ArrayList<>(JALAN.values());
    }

    static void saatPeristiwa(AccessibilityEvent e) {
        List<LuaMesin> l = salinan();
        if (l == null) return;
        LuaValue ev = LuaJava.wrap(e);
        for (LuaMesin m : l) if (m.berjalan() && m.punya("onAccessibilityEvent")) m.panggil("onAccessibilityEvent", ev);
    }

    /** Biarkan plugin mengubah ucapan. Fungsi onSpeak(teks): kembalikan string untuk mengganti, true untuk membatalkan. */
    static String saatUcap(String teks) {
        if (dalamUcap) return teks;
        List<LuaMesin> l = salinan();
        if (l == null) return teks;
        dalamUcap = true;
        try {
            for (LuaMesin m : l) {
                if (!m.berjalan() || !m.punya("onSpeak")) continue;
                Varargs r = m.panggil("onSpeak", LuaValue.valueOf(teks));
                LuaValue h = r.arg1();
                if (h.type() == LuaValue.TSTRING) teks = h.tojstring();
                else if (h.type() == LuaValue.TBOOLEAN && h.toboolean()) return null;
            }
        } finally {
            dalamUcap = false;
        }
        return teks;
    }

    /** onKeyEvent(event): kembalikan true untuk menelan tombol. */
    static boolean saatTombol(KeyEvent ev) {
        List<LuaMesin> l = salinan();
        if (l == null) return false;
        LuaValue v = LuaJava.wrap(ev);
        for (LuaMesin m : l) {
            if (!m.berjalan() || !m.punya("onKeyEvent")) continue;
            LuaValue h = m.panggil("onKeyEvent", v).arg1();
            if (h.type() == LuaValue.TBOOLEAN && h.toboolean()) return true;
        }
        return false;
    }
}
